T = readtable('crypto-query-tweets.csv');

tweetText = string(T.tweet_text);
dateText = string(T.date_time);

tweetDate = datetime(dateText, ...
    'InputFormat', 'yyyy-MM-dd HH:mm:ssXXX', ...
    'TimeZone', 'UTC');

CleanTweets = table(tweetDate, tweetText, ...
    'VariableNames', {'DateTime', 'TweetText'});

validRows = ~ismissing(CleanTweets.TweetText) & ...
    strlength(strtrim(CleanTweets.TweetText)) > 0 & ...
    ~isnat(CleanTweets.DateTime);

CleanTweets = CleanTweets(validRows, :);

[~, uniqueRows] = unique(CleanTweets.TweetText, 'stable');
CleanTweets = CleanTweets(uniqueRows, :);

CleanTweets = sortrows(CleanTweets, 'DateTime');

writetable(CleanTweets, 'crypto_tweets_cleaned.csv');

fprintf('Original tweets: %d\n', height(T));
fprintf('Clean tweets: %d\n', height(CleanTweets));

disp(CleanTweets(1:min(5,height(CleanTweets)), :));