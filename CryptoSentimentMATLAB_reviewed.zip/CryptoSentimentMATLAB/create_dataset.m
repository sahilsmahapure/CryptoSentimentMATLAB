clc;
clear;

% Generate demonstration cryptocurrency price data

rng(42);

numberOfDays = 180;

Date = (datetime('today') - days(numberOfDays-1):days(1):datetime('today'))';

dailyReturns = 0.001 + 0.025*randn(numberOfDays,1);

Close = zeros(numberOfDays,1);
Close(1) = 60000;

for i = 2:numberOfDays
    Close(i) = Close(i-1)*(1+dailyReturns(i));
end

Open = [Close(1); Close(1:end-1)];
High = max(Open,Close).*(1+0.005*rand(numberOfDays,1));
Low = min(Open,Close).*(1-0.005*rand(numberOfDays,1));
Volume = randi([1000,10000],numberOfDays,1);

cryptoData = table(Date,Open,High,Low,Close,Volume);

writetable(cryptoData,'crypto_prices.csv');

disp('Demonstration dataset created successfully!');
disp(head(cryptoData));

figure;
plot(Date,Close,'LineWidth',1.5);
title('Demonstration Bitcoin Closing Prices');
xlabel('Date');
ylabel('Price (USD)');
grid on;