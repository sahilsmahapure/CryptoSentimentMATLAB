clc;
clear;
close all;

fprintf('\n====================================\n');
fprintf(' CRYPTO SENTIMENT TRADING SYSTEM\n');
fprintf('====================================\n\n');

fprintf('Step 1: Generating cryptocurrency data...\n');
run('create_dataset.m');

fprintf('\nStep 2: Running sentiment analysis...\n');
run('sentiment_analysis_fixed.m');

fprintf('\nStep 3: Running trading strategy...\n');
run('trading_strategy.m');

fprintf('\n====================================\n');
fprintf(' PROJECT EXECUTION COMPLETED\n');
fprintf('====================================\n');

fprintf('\nGenerated output files:\n');
fprintf('1. crypto_prices.csv\n');
fprintf('2. sentiment_results.csv\n');
fprintf('3. trading_results.csv\n');

fprintf('\nAll project components executed successfully!\n');