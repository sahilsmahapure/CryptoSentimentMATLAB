clc;
clear;
close all;

% Load project results
crypto = readtable('crypto_prices.csv');
trading = readtable('trading_results.csv');
sentiment = readtable('sentiment_results.csv');

% Extract sentiment counts
positiveCount = sum(strcmp(sentiment.Sentiment,'Positive'));
negativeCount = sum(strcmp(sentiment.Sentiment,'Negative'));
neutralCount = sum(strcmp(sentiment.Sentiment,'Neutral'));

% Calculate performance
strategyEquity = trading.StrategyEquity;
buyHoldEquity = trading.BuyHoldEquity;

strategyReturn = (strategyEquity(end)-1)*100;
buyHoldReturn = (buyHoldEquity(end)-1)*100;

peakEquity = cummax(strategyEquity);
drawdown = (strategyEquity-peakEquity)./peakEquity;
maxDrawdown = min(drawdown)*100;

% Create dashboard window
fig = uifigure( ...
    'Name','Crypto Sentiment Trading Dashboard', ...
    'Position',[100 100 1200 750], ...
    'Color',[0.95 0.96 0.98]);

% Create grid layout
gl = uigridlayout(fig,[3 2]);
gl.RowHeight = {65,'1x','1x'};
gl.ColumnWidth = {'1x','1x'};
gl.Padding = [15 15 15 15];
gl.RowSpacing = 12;
gl.ColumnSpacing = 12;

% Dashboard title
titleLabel = uilabel(gl);
titleLabel.Text = 'CRYPTO SENTIMENT AND TRADING DASHBOARD';
titleLabel.FontSize = 21;
titleLabel.FontWeight = 'bold';
titleLabel.HorizontalAlignment = 'center';
titleLabel.Layout.Row = 1;
titleLabel.Layout.Column = [1 2];

% Price chart
ax1 = uiaxes(gl);
ax1.Layout.Row = 2;
ax1.Layout.Column = 1;

plot(ax1,trading.Date,trading.Price,'LineWidth',1.4);
hold(ax1,'on');

plot(ax1,trading.Date,trading.ShortMA,'LineWidth',1.2);
plot(ax1,trading.Date,trading.LongMA,'LineWidth',1.2);

buyPoints = find(trading.Signal == 1);
sellPoints = find(trading.Signal == -1);

plot(ax1,trading.Date(buyPoints), ...
    trading.Price(buyPoints),'^','MarkerSize',6);

plot(ax1,trading.Date(sellPoints), ...
    trading.Price(sellPoints),'v','MarkerSize',6);

title(ax1,'Cryptocurrency Price and Trading Signals');
xlabel(ax1,'Date');
ylabel(ax1,'Price (USD)');
legend(ax1,{'Closing Price','5-Day Average', ...
    '20-Day Average','Buy Signal','Sell Signal'}, ...
    'Location','best');
grid(ax1,'on');

% Equity comparison chart
ax2 = uiaxes(gl);
ax2.Layout.Row = 2;
ax2.Layout.Column = 2;

plot(ax2,trading.Date,strategyEquity,'LineWidth',1.7);
hold(ax2,'on');
plot(ax2,trading.Date,buyHoldEquity,'LineWidth',1.7);

title(ax2,'Strategy vs Buy and Hold');
xlabel(ax2,'Date');
ylabel(ax2,'Growth of $1');

legend(ax2,{'Trading Strategy','Buy and Hold'}, ...
    'Location','best');

grid(ax2,'on');

% Sentiment chart
ax3 = uiaxes(gl);
ax3.Layout.Row = 3;
ax3.Layout.Column = 1;

bar(ax3,[positiveCount,negativeCount,neutralCount]);

ax3.XTick = 1:3;
ax3.XTickLabel = {'Positive','Negative','Neutral'};

title(ax3,'Sentiment Analysis Results');
ylabel(ax3,'Number of Posts');
grid(ax3,'on');

% Performance summary
summaryPanel = uipanel(gl);
summaryPanel.Title = 'PERFORMANCE SUMMARY';
summaryPanel.FontSize = 14;
summaryPanel.FontWeight = 'bold';
summaryPanel.Layout.Row = 3;
summaryPanel.Layout.Column = 2;

summaryLayout = uigridlayout(summaryPanel,[5 1]);
summaryLayout.RowHeight = {'1x','1x','1x','1x','1x'};
summaryLayout.Padding = [15 15 15 15];

label1 = uilabel(summaryLayout);
label1.Text = sprintf('Strategy Return: %.2f%%',strategyReturn);
label1.FontSize = 17;
label1.FontWeight = 'bold';

label2 = uilabel(summaryLayout);
label2.Text = sprintf('Buy and Hold Return: %.2f%%',buyHoldReturn);
label2.FontSize = 17;

label3 = uilabel(summaryLayout);
label3.Text = sprintf('Maximum Drawdown: %.2f%%',maxDrawdown);
label3.FontSize = 17;

label4 = uilabel(summaryLayout);
label4.Text = sprintf('Positive Posts: %d',positiveCount);
label4.FontSize = 16;

label5 = uilabel(summaryLayout);
label5.Text = sprintf( ...
    'Negative: %d    Neutral: %d', ...
    negativeCount,neutralCount);
label5.FontSize = 16;

disp('Dashboard created successfully.');