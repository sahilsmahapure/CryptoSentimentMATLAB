% Cryptocurrency Sentiment Analysis
% Methods: VADER and Ratio-Based Sentiment

clearvars -except T CleanTweets
clc;

% Load cleaned tweets if not already in workspace
if ~exist('CleanTweets','var')
    CleanTweets = readtable('crypto_tweets_cleaned.csv');
end

% Convert tweet text to string array
tweets = string(CleanTweets.TweetText);
tweets(ismissing(tweets)) = "";

fprintf('Analyzing %d tweets...\n', numel(tweets));

%% 1. VADER Sentiment Analysis

numTweets = numel(tweets);

vaderCompound = zeros(numTweets,1);

fprintf('Running VADER on %d tweets...\n', numTweets);

for i = 1:numTweets
    doc = tokenizedDocument(tweets(i));
    vaderCompound(i) = vaderSentimentScores(doc);

    if mod(i,5000) == 0
        fprintf('Processed %d / %d tweets\n', i, numTweets);
    end
end

% Classify sentiment using compound scores
vaderLabel = strings(numTweets,1);

vaderLabel(vaderCompound >= 0.05) = "Positive";
vaderLabel(vaderCompound <= -0.05) = "Negative";
vaderLabel(vaderCompound > -0.05 & ...
    vaderCompound < 0.05) = "Neutral";

disp('VADER analysis completed.');
%% 2. Ratio-Based Sentiment Analysis

documents = tokenizedDocument(tweets);

[ratioCompound, ratioPositive, ratioNegative] = ...
    ratioSentimentScores(documents);

%% 3. Combine Results

SentimentResults = table( ...
    CleanTweets.DateTime, ...
    tweets, ...
    vaderCompound, ...
    vaderLabel, ...
    ratioCompound, ...
    ratioPositive, ...
    ratioNegative, ...
    'VariableNames', { ...
    'DateTime', ...
    'TweetText', ...
    'VADERCompound', ...
    'VADERLabel', ...
    'RatioCompound', ...
    'RatioPositive', ...
    'RatioNegative'});

writetable(SentimentResults, 'sentiment_results_real.csv');

fprintf('\nSentiment analysis completed.\n');
fprintf('Tweets analyzed: %d\n', height(SentimentResults));

disp(SentimentResults(1:min(5,height(SentimentResults)),:));
% Save results
writetable(SentimentResults, 'sentiment_results_real.csv');

fprintf('\nSentiment analysis completed.\n');
fprintf('Tweets analyzed: %d\n', height(SentimentResults));

disp(SentimentResults(1:min(5,height(SentimentResults)),:));