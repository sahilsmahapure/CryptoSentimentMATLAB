%% CRYPTOCURRENCY SENTIMENT ANALYSIS AND TRADING STRATEGY
% Uses the included historical Bitcoin prices and daily pre-scored sentiment.
% This script does NOT generate or overwrite synthetic crypto_prices.csv.

clc; clear; close all;
projectFolder = fileparts(mfilename('fullpath'));
if isempty(projectFolder), projectFolder = pwd; end
cd(projectFolder);

fprintf('\n===============================================\n');
fprintf(' CRYPTO SENTIMENT ANALYSIS AND BACKTEST\n');
fprintf('===============================================\n');

%% 1. Locate historical Bitcoin price data
pricePath = fullfile(projectFolder, ...
    'crypto_tweet_impact-main', 'data', 'processed', ...
    'BTC_USD_data_2013_to_present.csv');
if ~isfile(pricePath)
    error('Historical BTC price file not found: %s', pricePath);
end
P = readtable(pricePath);
requiredPriceVars = {'date','close','volume_usd'};
if ~all(ismember(requiredPriceVars, P.Properties.VariableNames))
    error('BTC CSV must contain columns: date, close, volume_usd.');
end
P.Date = datetime(string(P.date), 'InputFormat','yyyy-MM-dd');
P = sortrows(P,'Date');
P = P(:, {'Date','close','volume_usd'});
P.Properties.VariableNames = {'Date','Close','VolumeUSD'};
P = P(~isnat(P.Date) & isfinite(P.Close) & P.Close > 0,:);
[P.Date, keepP] = unique(P.Date,'stable');
P = P(keepP,:);

%% 2. Load daily pre-scored sentiment data
sentimentPath = fullfile(projectFolder,'daily_sentiment_real.csv');
if ~isfile(sentimentPath)
    error('daily_sentiment_real.csv was not found in the project folder.');
end
S = readtable(sentimentPath);
if ~all(ismember({'Date','TweetCount','MeanSentiment'}, S.Properties.VariableNames))
    error('Sentiment CSV must contain Date, TweetCount, MeanSentiment.');
end
if ~isdatetime(S.Date)
    S.Date = datetime(string(S.Date),'InputFormat','dd-MMM-yyyy');
end
S = sortrows(S,'Date');
S = S(~isnat(S.Date) & isfinite(S.MeanSentiment),:);
[S.Date, keepS] = unique(S.Date,'stable');
S = S(keepS,:);

%% 3. Align sentiment to historical daily prices
% Use only the period covered by the sentiment dataset. Dates without a
% sentiment record receive neutral score 5 and TweetCount 0.
firstSentimentDate = min(S.Date);
lastSentimentDate = max(S.Date);
P = P(P.Date >= firstSentimentDate & P.Date <= lastSentimentDate,:);
D = outerjoin(P,S,'Keys','Date','MergeKeys',true,'Type','left');
D = sortrows(D,'Date');
D = D(~isnat(D.Date) & isfinite(D.Close) & D.Close > 0,:);
D.TweetCount(ismissing(D.TweetCount)) = 0;
D.MeanSentiment(ismissing(D.MeanSentiment)) = 5;

if height(D) < 30
    error('Only %d matched price rows. Check the sentiment and BTC date formats.',height(D));
end

fprintf('\n===== DATA CHECK =====\n');
fprintf('Historical price rows in overlap: %d\n',height(D));
fprintf('Date range: %s to %s\n',string(D.Date(1)),string(D.Date(end)));
fprintf('Days with sentiment records: %d\n',sum(D.TweetCount > 0));
fprintf('Average sentiment score: %.3f\n',mean(D.MeanSentiment,'omitnan'));

%% 4. Create indicators and signals
prices = D.Close;
dates = D.Date;
sentiment = D.MeanSentiment;
n = height(D);
shortMA = movmean(prices,[4 0]);       % 5-day moving average
longMA = movmean(prices,[19 0]);       % 20-day moving average

dailyReturns = [0; prices(2:end)./prices(1:end-1)-1];
signal = zeros(n,1);                  % 1 = long, -1 = short/exit bias, 0 = flat
hasSentiment = D.TweetCount > 0;
for i = 20:n
    if hasSentiment(i) && sentiment(i) >= 6 && shortMA(i) > longMA(i)
        signal(i) = 1;
    elseif hasSentiment(i) && sentiment(i) <= 4 && shortMA(i) < longMA(i)
        signal(i) = -1;
    end
end

% Lag signals one day so today's return never uses today's signal.
position = [0; signal(1:end-1)];
transactionCost = 0.001;              % 0.1% per position change
positionChanges = [0; abs(diff(position))];
strategyReturns = position .* dailyReturns - positionChanges .* transactionCost;
buyHoldReturns = dailyReturns;

% Guard against impossible equity values from invalid returns.
if any(1 + strategyReturns <= 0) || any(1 + buyHoldReturns <= 0)
    error('Invalid return less than or equal to -100%% encountered.');
end
strategyEquity = cumprod(1 + strategyReturns);
buyHoldEquity = cumprod(1 + buyHoldReturns);

strategyTotalReturn = (strategyEquity(end)-1)*100;
buyHoldTotalReturn = (buyHoldEquity(end)-1)*100;
strategyDrawdown = (strategyEquity-cummax(strategyEquity))./cummax(strategyEquity);
buyHoldDrawdown = (buyHoldEquity-cummax(buyHoldEquity))./cummax(buyHoldEquity);
strategyMaxDrawdown = min(strategyDrawdown)*100;
buyHoldMaxDrawdown = min(buyHoldDrawdown)*100;
strategyVolatility = std(strategyReturns(2:end),'omitnan')*sqrt(365)*100;
if std(strategyReturns(2:end),'omitnan') > 0
    sharpeRatio = mean(strategyReturns(2:end),'omitnan') / std(strategyReturns(2:end),'omitnan') * sqrt(365);
else
    sharpeRatio = NaN;
end

%% 5. Export backtest and performance report
Results = table(dates,D.TweetCount,sentiment,prices,D.VolumeUSD,shortMA,longMA, ...
    signal,position,dailyReturns,strategyReturns,strategyEquity,buyHoldEquity, ...
    strategyDrawdown,buyHoldDrawdown, ...
    'VariableNames',{'Date','TweetCount','MeanSentiment','Close','VolumeUSD', ...
    'ShortMA5','LongMA20','Signal','Position','DailyReturn','StrategyReturn', ...
    'StrategyEquity','BuyHoldEquity','StrategyDrawdown','BuyHoldDrawdown'});
writetable(Results,fullfile(projectFolder,'improved_strategy_results.csv'));

Metric = ["Date range"; "Price rows"; "Days with sentiment"; ...
    "Strategy total return (%)"; "Buy-and-hold total return (%)"; ...
    "Strategy maximum drawdown (%)"; "Buy-and-hold maximum drawdown (%)"; ...
    "Annualized strategy volatility (%)"; "Annualized Sharpe ratio"; ...
    "Buy signal days"; "Sell signal days"; "Flat signal days"];
Value = [string(dates(1)) + " to " + string(dates(end)); string(n); ...
    string(sum(D.TweetCount > 0)); string(sprintf('%.4f',strategyTotalReturn)); ...
    string(sprintf('%.4f',buyHoldTotalReturn)); string(sprintf('%.4f',strategyMaxDrawdown)); ...
    string(sprintf('%.4f',buyHoldMaxDrawdown)); string(sprintf('%.4f',strategyVolatility)); ...
    string(sprintf('%.4f',sharpeRatio)); string(sum(signal==1)); string(sum(signal==-1)); string(sum(signal==0))];
PerformanceReport = table(Metric,Value);
writetable(PerformanceReport,fullfile(projectFolder,'performance_report_real.csv'));

fprintf('\n===== BACKTEST RESULTS =====\n');
fprintf('Strategy total return: %.2f%%\n',strategyTotalReturn);
fprintf('Buy-and-hold total return: %.2f%%\n',buyHoldTotalReturn);
fprintf('Strategy max drawdown: %.2f%%\n',strategyMaxDrawdown);
fprintf('Buy-and-hold max drawdown: %.2f%%\n',buyHoldMaxDrawdown);
fprintf('Annualized strategy volatility: %.2f%%\n',strategyVolatility);
fprintf('Annualized Sharpe ratio: %.3f\n',sharpeRatio);
fprintf('Signals: %d buy, %d sell, %d flat\n',sum(signal==1),sum(signal==-1),sum(signal==0));

%% 6. Create final analysis figure
fig = figure('Name','Crypto Sentiment Analysis Results','Color','w');
tiledlayout(fig,2,2,'Padding','compact','TileSpacing','compact');

nexttile;
plot(dates,prices,'LineWidth',1.0); hold on;
plot(dates,shortMA,'LineWidth',1.0);
plot(dates,longMA,'LineWidth',1.0);
buyIdx = find(signal==1); sellIdx = find(signal==-1);
plot(dates(buyIdx),prices(buyIdx),'^','MarkerSize',4);
plot(dates(sellIdx),prices(sellIdx),'v','MarkerSize',4);
title('Bitcoin Price and Signals'); xlabel('Date'); ylabel('Price (USD)');
legend('Close','5-day MA','20-day MA','Buy','Sell','Location','best'); grid on;

nexttile;
plot(dates,strategyEquity,'LineWidth',1.4); hold on;
plot(dates,buyHoldEquity,'LineWidth',1.4);
title('Strategy vs Buy-and-Hold'); xlabel('Date'); ylabel('Growth of $1');
legend('Sentiment strategy','Buy-and-hold','Location','best'); grid on;

nexttile;
histogram(D.MeanSentiment);
title('Daily Sentiment Score Distribution'); xlabel('Mean sentiment score'); ylabel('Number of days'); grid on;

nexttile;
plot(dates,100*strategyDrawdown,'LineWidth',1.1); hold on;
plot(dates,100*buyHoldDrawdown,'LineWidth',1.1);
title('Drawdown Comparison'); xlabel('Date'); ylabel('Drawdown (%)');
legend('Sentiment strategy','Buy-and-hold','Location','best'); grid on;

try
    exportgraphics(fig,fullfile(projectFolder,'crypto_sentiment_results.png'),'Resolution',180);
catch
    saveas(fig,fullfile(projectFolder,'crypto_sentiment_results.png'));
end

fprintf('\n===== PROJECT RUN COMPLETE =====\n');
fprintf('Created: improved_strategy_results.csv\n');
fprintf('Created: performance_report_real.csv\n');
fprintf('Created: crypto_sentiment_results.png\n');
fprintf('\nNOTE: Sentiment values in daily_sentiment_real.csv are pre-scored values,\n');
fprintf('not raw VADER scores. The trading backtest is a historical simulation,\n');
fprintf('not a guarantee of future returns.\n');
