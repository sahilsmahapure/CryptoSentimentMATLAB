clc;
clear;
close all;

% Load cryptocurrency price data
data = readtable('crypto_prices.csv');

prices = data.Close;
dates = data.Date;
n = length(prices);

% Calculate daily returns
dailyReturns = zeros(n,1);

for i = 2:n
    dailyReturns(i) = prices(i)/prices(i-1) - 1;
end

% Calculate moving averages
shortMA = movmean(prices,[4 0]);
longMA = movmean(prices,[19 0]);

% Load sentiment results
sentimentData = readtable('sentiment_results.csv');

scores = sentimentData.Score;
averageSentiment = mean(scores);

% Create sentiment direction
if averageSentiment > 0
    sentimentSignal = 1;
elseif averageSentiment < 0
    sentimentSignal = -1;
else
    sentimentSignal = 0;
end

% Generate trading signals
signal = zeros(n,1);

for i = 20:n
    if shortMA(i) > longMA(i) && sentimentSignal >= 0
        signal(i) = 1;
    elseif shortMA(i) < longMA(i) && sentimentSignal <= 0
        signal(i) = -1;
    else
        signal(i) = 0;
    end
end

% Use previous day's signal to avoid same-day look-ahead
position = [0; signal(1:end-1)];

% Calculate strategy returns
strategyReturns = position .* dailyReturns;

% Apply a simple transaction cost
transactionCost = 0.001;
changes = [0; abs(diff(position))];
strategyReturns = strategyReturns - changes .* transactionCost;

% Calculate buy-and-hold returns
buyHoldReturns = dailyReturns;

% Calculate growth of $1
strategyEquity = cumprod(1 + strategyReturns);
buyHoldEquity = cumprod(1 + buyHoldReturns);

% Calculate total returns
strategyTotalReturn = (strategyEquity(end)-1)*100;
buyHoldTotalReturn = (buyHoldEquity(end)-1)*100;

% Calculate maximum drawdown
strategyPeak = cummax(strategyEquity);
strategyDrawdown = (strategyEquity-strategyPeak)./strategyPeak;
maxDrawdown = min(strategyDrawdown)*100;

% Display results
fprintf('\nCRYPTO TRADING BACKTEST RESULTS\n');
fprintf('-------------------------------\n');
fprintf('Strategy total return: %.2f%%\n',strategyTotalReturn);
fprintf('Buy and hold return: %.2f%%\n',buyHoldTotalReturn);
fprintf('Strategy maximum drawdown: %.2f%%\n',maxDrawdown);
fprintf('Average sentiment score: %.2f\n',averageSentiment);

% Plot price and moving averages
figure;
plot(dates,prices,'LineWidth',1.2);
hold on;
plot(dates,shortMA,'LineWidth',1.2);
plot(dates,longMA,'LineWidth',1.2);

buyPoints = find(signal == 1);
sellPoints = find(signal == -1);

plot(dates(buyPoints),prices(buyPoints),'^',...
    'MarkerSize',7,'LineWidth',1.5);

plot(dates(sellPoints),prices(sellPoints),'v',...
    'MarkerSize',7,'LineWidth',1.5);
title('Cryptocurrency Price and Moving Averages');
xlabel('Date');
ylabel('Price (USD)');
legend('Closing Price','5-Day Average','20-Day Average',...
    'Buy Signal','Sell Signal');
grid on;

% Plot equity comparison
figure;
plot(dates,strategyEquity,'LineWidth',1.5);
hold on;
plot(dates,buyHoldEquity,'LineWidth',1.5);
title('Trading Strategy vs Buy and Hold');
xlabel('Date');
ylabel('Growth of $1');
legend('Trading Strategy','Buy and Hold');
grid on;

% Save results
output = table(dates,prices,shortMA,longMA,signal,...
    dailyReturns,strategyReturns,strategyEquity,buyHoldEquity,...
    'VariableNames',{'Date','Price','ShortMA','LongMA','Signal',...
    'DailyReturn','StrategyReturn','StrategyEquity','BuyHoldEquity'});

writetable(output,'trading_results.csv');

disp('Trading strategy completed successfully.');
disp('Results saved to trading_results.csv');