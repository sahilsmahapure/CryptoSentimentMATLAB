clc;
clear;
close all;

posts = {
    'Bitcoin is rising and investors are optimistic'
    'Crypto growth looks promising'
    'Bitcoin could reach a new high'
    'Investors are excited about crypto'
    'Bitcoin has a bright future'
    'Bitcoin prices are falling'
    'The market crash caused losses'
    'Investors are worried about declining prices'
    'The market looks weak'
    'Traders fear more losses'
    'Bitcoin is stable today'
    'Prices remain unchanged'
    'Traders are waiting for news'
    'Trading activity is normal'
    'The market is moving sideways'
};

positiveWords = {
    'rising'
    'optimistic'
    'growth'
    'promising'
    'high'
    'excited'
    'bright'
    'future'
    'profit'
    'good'
};

negativeWords = {
    'falling'
    'crash'
    'losses'
    'worried'
    'declining'
    'weak'
    'fear'
    'bad'
    'drop'
    'risk'
};

n = length(posts);
scores = zeros(n,1);
sentiments = cell(n,1);

for i = 1:n
    txt = lower(posts{i});
    p = 0;
    q = 0;

    for j = 1:length(positiveWords)
        if ~isempty(strfind(txt,positiveWords{j}))
            p = p + 1;
        end
    end

    for j = 1:length(negativeWords)
        if ~isempty(strfind(txt,negativeWords{j}))
            q = q + 1;
        end
    end

    scores(i) = p - q;

    if scores(i) > 0
        sentiments{i} = 'Positive';
    elseif scores(i) < 0
        sentiments{i} = 'Negative';
    else
        sentiments{i} = 'Neutral';
    end
end

results = table(posts,scores,sentiments,...
    'VariableNames',{'Post','Score','Sentiment'});

disp(results);

positiveCount = sum(strcmp(sentiments,'Positive'));
negativeCount = sum(strcmp(sentiments,'Negative'));
neutralCount = sum(strcmp(sentiments,'Neutral'));

fprintf('Positive posts: %d\n',positiveCount);
fprintf('Negative posts: %d\n',negativeCount);
fprintf('Neutral posts: %d\n',neutralCount);

figure;
bar([positiveCount,negativeCount,neutralCount]);
set(gca,'XTick',1:3);
set(gca,'XTickLabel',{'Positive','Negative','Neutral'});
title('Cryptocurrency Sentiment Analysis');
ylabel('Number of Posts');
grid on;

writetable(results,'sentiment_results.csv');

disp('Sentiment analysis completed successfully.');