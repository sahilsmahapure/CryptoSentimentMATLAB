%% DAILY CRYPTO SENTIMENT AND BITCOIN ANALYSIS

clearvars -except S
clc;
projectFolder = pwd;
%% 1. Load sentiment results
if ~exist('S','var')
    S = readtable('sentiment_results_real.csv');
end

% Convert timestamps to datetime if necessary
if ~isdatetime(S.DateTime)
    S.DateTime = datetime(S.DateTime);
end

% Extract calendar dates
S.Date = dateshift(S.DateTime, 'start', 'day');

%% 2. Aggregate sentiment by day

S.Date = dateshift(S.DateTime,'start','day');

[dates,~,groupIndex] = unique(S.Date);

DailySentiment = table;
DailySentiment.Date = dates;

DailySentiment.TweetCount = accumarray(groupIndex,1);

DailySentiment.MeanVADER = accumarray( ...
    groupIndex,S.VADERCompound,[],@mean);

DailySentiment.MeanRatio = accumarray( ...
    groupIndex,S.RatioCompound,[],@mean);

DailySentiment = sortrows(DailySentiment,'Date');

writetable(DailySentiment,'daily_sentiment.csv');

fprintf('Daily sentiment records: %d\n',height(DailySentiment));
%% 3. Load Bitcoin prices

projectFolder = pwd;

priceFiles = dir(fullfile(projectFolder, '**', ...
    'BTC_USD_data_2013_to_present.csv'));

if isempty(priceFiles)
    error('Bitcoin price CSV not found.');
end

priceFile = fullfile(priceFiles(1).folder, ...
    priceFiles(1).name);

PriceData = readtable(priceFile);

PriceData.Date = datetime(PriceData.date, ...
    'InputFormat', 'yyyy-MM-dd');

PriceData = sortrows(PriceData, 'Date');

%% 4. Match sentiment with Bitcoin prices

CombinedData = innerjoin( ...
    DailySentiment, PriceData, ...
    'LeftKeys', 'Date', ...
    'RightKeys', 'Date');

CombinedData = sortrows(CombinedData, 'Date');

writetable(CombinedData, 'combined_crypto_sentiment.csv');

fprintf('\nCombined dataset created.\n');
fprintf('Matching dates: %d\n', height(CombinedData));

disp(CombinedData);