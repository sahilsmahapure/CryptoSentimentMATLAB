clc;
clear;
close all;

%% 1. Load daily sentiment data
S = readtable('daily_sentiment_real.csv');

S.Date = dateshift(S.Date, 'start', 'day');
S = sortrows(S, 'Date');

% Remove duplicate dates if present
[S.Date, ia] = unique(S.Date, 'stable');
S = S(1:length(ia), :);

%% 2. Load Bitcoin price data
P = readtable('crypto_prices.csv');

P.Date = dateshift(P.Date, 'start', 'day');
P = sortrows(P, 'Date');

[P.Date, ia] = unique(P.Date, 'stable');
P = P(1:length(ia), :);

%% 3. Align sentiment and price dates
D = innerjoin(S, P, 'Keys', 'Date');
D = sortrows(D, 'Date');

% Remove rows with invalid values
valid = isfinite(D.MeanSentiment) & ...
        isfinite(D.Close) & D.Close > 0;

D = D(valid, :);

fprintf('Matched records: %d\n', height(D));
fprintf('Date range: %s to %s\n', ...
    string(min(D.Date)), string(max(D.Date)));

%% 4. Calculate price returns
prices = D.Close;
dates = D.Date;
sentiment = D.MeanSentiment;

n = height(D);

dailyReturns = [0; prices(2:end)./prices(1:end-1)-1];

%% 5. Calculate moving averages
shortMA = movmean(prices, [4 0]);
longMA = movmean(prices, [19 0]);

%% 6. Generate daily sentiment signals
% Provisional thresholds. Verify the sentiment scale first.
signal = zeros(n,1);

for i = 20:n

    if sentiment(i) >= 6 && shortMA(i) > longMA(i)
        signal(i) = 1;

    elseif sentiment(i) <= 4 && shortMA(i) < longMA(i)
        signal(i) = -1;

    else
        signal(i) = 0;
    end

end

%% 7. Apply previous day's signal
% This avoids using today's signal for today's return.
position = [0; signal(1:end-1)];

%% 8. Calculate strategy returns
transactionCost = 0.001;

changes = [0; abs(diff(position))];

strategyReturns = position .* dailyReturns ...
                  - changes .* transactionCost;

buyHoldReturns = dailyReturns;

%% 9. Calculate equity curves
strategyEquity = cumprod(1 + strategyReturns);
buyHoldEquity = cumprod(1 + buyHoldReturns);

strategyTotalReturn = ...
    (strategyEquity(end)-1)*100;

buyHoldTotalReturn = ...
    (buyHoldEquity(end)-1)*100;

%% 10. Calculate maximum drawdown
strategyPeak = cummax(strategyEquity);
buyHoldPeak = cummax(buyHoldEquity);

strategyDrawdown = ...
    (strategyEquity-strategyPeak)./strategyPeak;

buyHoldDrawdown = ...
    (buyHoldEquity-buyHoldPeak)./buyHoldPeak;

strategyMaxDrawdown = min(strategyDrawdown)*100;
buyHoldMaxDrawdown = min(buyHoldDrawdown)*100;

%% 11. Display performance
fprintf('\n===== IMPROVED STRATEGY RESULTS =====\n');

fprintf('Strategy total return: %.2f%%\n', ...
    strategyTotalReturn);

fprintf('Buy-and-hold total return: %.2f%%\n', ...
    buyHoldTotalReturn);

fprintf('Strategy maximum drawdown: %.2f%%\n', ...
    strategyMaxDrawdown);

fprintf('Buy-and-hold maximum drawdown: %.2f%%\n', ...
    buyHoldMaxDrawdown);

fprintf('Buy days: %d\n', sum(signal == 1));
fprintf('Sell days: %d\n', sum(signal == -1));
fprintf('Hold days: %d\n', sum(signal == 0));

%% 12. Plot equity comparison
figure;

plot(dates, strategyEquity, 'LineWidth', 1.5);
hold on;
plot(dates, buyHoldEquity, 'LineWidth', 1.5);

title('Daily Sentiment Trading Strategy vs Buy-and-Hold');
xlabel('Date');
ylabel('Growth of $1');

legend('Sentiment Strategy', 'Buy-and-Hold', ...
       'Location', 'best');

grid on;

%% 13. Save results
Results = table(dates, sentiment, prices, shortMA, ...
    longMA, signal, position, dailyReturns, ...
    strategyReturns, strategyEquity, buyHoldEquity, ...
    'VariableNames', {'Date','MeanSentiment','Price', ...
    'ShortMA','LongMA','Signal','Position', ...
    'DailyReturn','StrategyReturn','StrategyEquity', ...
    'BuyHoldEquity'});

writetable(Results, 'improved_strategy_results.csv');

disp('Results saved to improved_strategy_results.csv');