clc;
clear;
disp('MATLAB is working!');
x = [1 2 3 4 5];
disp(mean(x));