function sentiment_analysis()

clc;

% Sample cryptocurrency-related posts
% These are demonstration examples, not live Twitter data.

posts = [
"Bitcoin is rising strongly and investors are optimistic"
"Crypto adoption is increasing and the market looks promising"
"Bitcoin could reach a new high"
"Blockchain technology has a bright future"
"Investors are excited about cryptocurrency growth"
"Bitcoin prices are falling sharply"
"The market crash has caused heavy losses"
"Crypto investors are worried about declining prices"
"The market looks weak and bearish"
"Investors fear further losses"
"Bitcoin is trading sideways today"
"The cryptocurrency market remains stable"
"Traders are waiting for more information"
"Prices have shown little movement"
"Trading activity remains normal"
];

% Positive and negative word dictionaries

positiveWords = [
"rising","strongly","optimistic","increasing","promising", ...
"high","bright","future","excited","growth","profit","bullish", ...
"gain","good","positive"
];

negativeWords = [
"falling","crash","losses","worried","declining","weak", ...
"bearish","fear","bad","negative","drop","risk","crisis"
];

numberOfPosts = length(posts);

scores = zeros(numberOfPosts,1);
labels = strings(numberOfPosts,1);

% Analyse every post

for i = 1:numberOfPosts

```
textValue = lower(char(posts(i)));

positiveCount = 0;
negativeCount = 0;

for j = 1:length(positiveWords)
    positiveCount = positiveCount + ...
        count(string(textValue),positiveWords(j));
end

for j = 1:length(negativeWords)
    negativeCount = negativeCount + ...
        count(string(textValue),negativeWords(j));
end

scores(i) = positiveCount - negativeCount;

if scores(i) > 0
    labels(i) = "Positive";
elseif scores(i) < 0
    labels(i) = "Negative";
else
    labels(i) = "Neutral";
end
```

end

% Create results table

results = table(posts,scores,labels, ...
'VariableNames',{'Post','Score','Sentiment'});

disp('CRYPTOCURRENCY SENTIMENT ANALYSIS');
disp(results);

% Calculate sentiment distribution

positiveTotal = sum(labels == "Positive");
negativeTotal = sum(labels == "Negative");
neutralTotal = sum(labels == "Neutral");

fprintf('\nPositive posts: %d\n',positiveTotal);
fprintf('Negative posts: %d\n',negativeTotal);
fprintf('Neutral posts: %d\n',neutralTotal);

% Plot sentiment distribution

figure;

bar([positiveTotal,negativeTotal,neutralTotal]);

set(gca,'XTick',1:3);
set(gca,'XTickLabel',{'Positive','Negative','Neutral'});

title('Cryptocurrency Sentiment Distribution');
xlabel('Sentiment');
ylabel('Number of Posts');

grid on;

% Export results

writetable(results,'sentiment_results.csv');

disp('Sentiment results saved to sentiment_results.csv');

end
